import sys
import pygame
from sys import exit
from pygame.locals import *
import time

pygame.init()
screen = pygame.display.set_mode((900, 700))
pygame.display.set_caption('Python Jeopardy')

#font
credit_font = pygame.font.Font('font/new.ttf', 20)
credit = credit_font.render('Creator: Aziz Hamad', False, 'brown')


long_font = pygame.font.Font('font/new.ttf', 40)


boxA = pygame.image.load('pics/boxA.png')
boxB = pygame.image.load('pics/boxB.png')
boxC = pygame.image.load('pics/boxC.png')
boxD = pygame.image.load('pics/boxD.png')

#extra images for design
quizword = pygame.image.load('pics/word_question.png')
levels = pygame.image.load('pics/levels.png')
X = pygame.image.load('pics/X.png')
sad_face = pygame.image.load('pics/sad_face.png')
happy_face = pygame.image.load('pics/happy_face.png')
checkmark = pygame.image.load('pics/checkmark.png')






#background 
blue_background = (235,245,255)
screen.fill(blue_background)

# Question & Options ~ Beginner
q1_begin = pygame.image.load('pics/Q1_begin.png')
q1_b_options = pygame.image.load('pics/Q1_b_options.png')
q2_begin = pygame.image.load('pics/Q2_begin.png')
q2_b_options = pygame.image.load('pics/Q2_b_options.png')
q3_begin = pygame.image.load('pics/Q3_begin.png')
q3_b_options = pygame.image.load('pics/Q3_b_options.png')
q4_begin = pygame.image.load('pics/Q4_begin.png')
q4_b_options = pygame.image.load('pics/Q4_b_options.png')

# Question & Options ~ pro
q1_pro = pygame.image.load('pics/Q1_pro.png')
q1_p_options = pygame.image.load('pics/Q1_p_options.png')
q2_pro = pygame.image.load('pics/Q2_pro.png')
q2_p_options = pygame.image.load('pics/Q2_p_options.png')
q3_pro = pygame.image.load('pics/Q3_pro.png')
q3_p_options = pygame.image.load('pics/Q3_p_options.png')
q4_pro = pygame.image.load('pics/Q4_pro.png')
q4_p_options = pygame.image.load('pics/Q4_p_options.png')


# Question & Options ~ expert
q1_expert = pygame.image.load('pics/Q1_expert.png')
q1_e_options = pygame.image.load('pics/Q1_e_options.png')
q2_expert = pygame.image.load('pics/Q2_expert.png')
q2_e_options = pygame.image.load('pics/Q2_e_options.png')
q3_expert = pygame.image.load('pics/Q3_expert.png')
q3_e_options = pygame.image.load('pics/Q3_e_options.png')
q4_expert = pygame.image.load('pics/Q4_expert.png')
q4_e_options = pygame.image.load('pics/Q4_e_options.png')

#wrong answers   
wrongA = long_font.render('Wrong\n the correct answer is A', False, 'brown')
wrongB = long_font.render('Wrong\n the correct answer is B', False, 'brown')
wrongC = long_font.render('Wrong\n the correct answer is C', False, 'brown')
wrongD = long_font.render('Wrong\n the correct answer is D', False, 'brown')

#correct answer
correct_ans = long_font.render('you are correct!', False, 'brown')

#beginners set
questions_1 = [
    {'answer': 'B', 'q_options': q1_b_options, 'Question': q1_begin},
    {'answer': 'C', 'q_options': q2_b_options, 'Question': q2_begin},
    {'answer': 'C', 'q_options': q3_b_options, 'Question': q3_begin},
    {'answer': 'C', 'q_options': q4_b_options, 'Question': q4_begin}
    
]
#pro set
questions_2 = [
    {'answer': 'D', 'q_options': q1_p_options, 'Question': q1_pro},
    {'answer': 'D', 'q_options': q2_p_options, 'Question': q2_pro},
    {'answer': 'B', 'q_options': q3_p_options, 'Question': q3_pro},
    {'answer': 'D', 'q_options': q4_p_options, 'Question': q4_pro}
]
#expert set
questions_3 = [
    {'answer': 'A', 'q_options': q1_e_options, 'Question': q1_expert}, 
    {'answer': 'B', 'q_options': q2_e_options, 'Question': q2_expert}, 
    {'answer': 'A', 'q_options': q3_e_options, 'Question': q3_expert},
    {'answer': 'C', 'q_options': q4_e_options, 'Question': q4_expert}
]

score = 0
number = 0


def initialize_quiz_elements():
    rectA = pygame.Rect((60, 500), (160, 150))
    rectB = pygame.Rect((275, 500), (160, 150))
    rectC = pygame.Rect((490, 500), (160, 150))
    rectD = pygame.Rect((705, 500), (160, 150))


    

    return rectA, rectB, rectC, rectD

def blit_quiz_elements(screen, boxA, boxB, boxC, boxD, rectA, rectB, rectC, rectD):
    screen.blit(boxA, (rectA.x, rectA.y))
    screen.blit(boxB, (rectB.x, rectB.y))
    screen.blit(boxC, (rectC.x, rectC.y))
    screen.blit(boxD, (rectD.x, rectD.y))

def get_correct_rect(answer):
    if answer == 'A':
        correct = rectA
    elif answer == 'B':
        correct = rectB
    elif answer == 'C':
        correct = rectC
    elif answer == 'D':
        correct = rectD
    return correct


def handle_quiz_start(number):
    global Not_Pressed, running
    Not_Pressed = False
    running = True



    for question in get_questions_by_number(number):
        if not running:
            break

        screen.fill(blue_background)
        screen.blit(quizword, (320, -50))
        screen.blit(question['Question'], (56, 160))
        pygame.display.flip()

        pygame.time.wait(5000)

        Question_Prompt(question['answer'], question['q_options'], question['Question'])
        
        
    if running:
        handle_quiz_end()

def handle_quiz_end():
    global running
    screen.fill(blue_background)
    if score == len(get_questions_by_number(number)):
        screen.blit(long_font.render(f'Congratulations! You got {score}', False, 'brown'), (50,300))
        screen.blit(long_font.render(f' out of {len(get_questions_by_number(number))} questions correct!', False, 'brown'), (50,340))
        screen.blit(happy_face, (50, 500))
        screen.blit(checkmark, (600, 0))
        
    else:
        screen.blit(long_font.render(f'You got {score} out of {len(get_questions_by_number(number))} questions correct.', False, 'brown'), (50,300))
        screen.blit(long_font.render(f'Better luck next time!', False, 'brown'), (50,340))
        screen.blit(X, (50, 500))
        screen.blit(sad_face, (600, 0))
    pygame.display.flip()
    pygame.time.wait(5000)
    running = False


# Initialize quiz elements
rectA, rectB, rectC, rectD = initialize_quiz_elements()

pygame.display.flip()
Not_Pressed = True
def Question_Prompt(answer, q_options, question):
    global score
    screen.fill(blue_background)
    running = True

    blit_quiz_elements(screen, boxA, boxB, boxC, boxD, rectA, rectB, rectC, rectD)
    screen.blit(q_options, (520, 155))
    screen.blit(question, (50, 155))
    screen.blit(quizword, (320, -50))

    correct = get_correct_rect(answer)

    pygame.display.flip()

    def display_wrong_answer(answer):
        screen.fill(blue_background)
        if answer == 'A':
            screen.blit(wrongA, (50,300))
            screen.blit(X, (50, 500))
            screen.blit(sad_face, (600, 0))
        elif answer == 'B':
            screen.blit(wrongB,(50,300))
            screen.blit(X, (50, 500))
            screen.blit(sad_face, (600, 0))

        elif answer == 'C':
            screen.blit(wrongC, (50,300))
            screen.blit(X, (50, 500))
            screen.blit(sad_face, (600, 0))
        elif answer == 'D':   
            screen.blit(wrongD, (50,300))
            screen.blit(X, (50, 500))
            screen.blit(sad_face, (600, 0))
        pygame.display.flip()                        
        pygame.time.wait(5000)

    while running:
        mx, my = pygame.mouse.get_pos()
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                exit()

            if correct.collidepoint((mx, my)):
                if event.type == MOUSEBUTTONDOWN:
                    if event.button == 1:
                        screen.fill(blue_background)
                        screen.blit(correct_ans, (50, 300))
                        screen.blit(happy_face, (50, 500))
                        screen.blit(checkmark, (600, 0))
                        pygame.display.flip()
                        score += 1
                        
                        
                        pygame.time.wait(5000)
                        running = False

            elif rectA.collidepoint((mx,my)) or rectB.collidepoint((mx,my)) or rectC.collidepoint((mx,my)) or rectD.collidepoint((mx,my)):
                if event.type == MOUSEBUTTONDOWN:
                    if event.button ==1:
                        display_wrong_answer(answer)
                        running = False

def get_questions_by_number(number):
    if number == 1:
        questions = questions_1
    elif number == 2:
        questions = questions_2
    else:
        questions = questions_3
    return questions

pygame.display.flip()

while Not_Pressed:
    for event in pygame.event.get():
        
        screen.blit(levels, (0, 0))
        screen.blit(credit, (10, 640))
        
        pygame.display.flip()
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_1:
                number = 1
                handle_quiz_start(number)
            elif event.key == pygame.K_2:
                number = 2
                handle_quiz_start(number)
            elif event.key == pygame.K_3:
                number = 3
                handle_quiz_start(number)


    

while True:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            sys.exit()
    pygame.display.update()
